// psig.c ... functions on page signatures (psig's)
// part of signature indexed files
// Written by John Shepherd, March 2019

#include "defs.h"
#include "reln.h"
#include "query.h"
#include "psig.h"
#include "hash.h"

Bits generatePSigCodeWord (char *attr_value, int tupleSigBits, int codeWordBits)
{
    int nbits = 0;
    Bits cword = newBits(tupleSigBits);
    srandom(hash_any(attr_value, strlen(attr_value)));

    while (nbits < codeWordBits) {
        int i = random() % tupleSigBits;
        if (!bitIsSet(cword, i)) {
            setBit(cword, i);
            nbits++;
        }
    }
    return cword;
}

Bits makePageSig(Reln r, Tuple t)
{
	assert(r != NULL && t != NULL);
	//TODO
    int nbitsOfPsig = psigBits(r);// Page signature (page descriptor) bits
    Bits Psig = newBits(nbitsOfPsig);
    char **attrsArray = tupleVals(r, t);
    int nattr = nAttrs(r);// Number of attributes

    for (int i = 0; i < nattr; ++i) {
        if (strncmp(attrsArray[i], "?", 1) == 0) {
            continue;
        }
        else {
            Bits cword = generatePSigCodeWord(attrsArray[i], psigBits(r), codeBits(r));
            orBits(Psig, cword);
        }
    }
    return Psig;
}

void findPagesUsingPageSigs(Query q)
{
	assert(q != NULL);
	//TODO
    Reln r = q->rel;
    Bits querySig = makePageSig(r, q->qstring);// Making query signature (query descriptor)
    Count numOfPageSigPages = nPsigPages(r);// Number of pages to store page signature (page descriptor)
    File pageSigFile = psigFile(r);
    Count nbitsOfPsig = psigBits(r);
    Bits pageSig = newBits(nbitsOfPsig);

    for (int pid = 0; pid < numOfPageSigPages; ++pid) {
        Page p = getPage(pageSigFile, pid);
        Count numOfPageSig = pageNitems(p);

        for (int pSigID = 0; pSigID < numOfPageSig; ++pSigID) {

            getBits(p, pSigID, pageSig);
            if (isSubset(querySig, pageSig) == TRUE) {
                Offset pageOffset = q->nsigs;
                setBit(q->pages, pageOffset);
            }
            q->nsigs++;
        }
        q->nsigpages++;
    }
    // The printf below is primarily for debugging
    // Remove it before submitting this function
//    printf("Matched Pages:"); showBits(q->pages); putchar('\n');
}

