// tsig.c ... functions on Tuple Signatures (tsig's)
// part of signature indexed files
// Written by John Shepherd, March 2019

#include <unistd.h>
#include <string.h>
#include "defs.h"
#include "tsig.h"
#include "reln.h"
#include "hash.h"
#include "bits.h"

Bits generateCodeWord (char *attr_value, int tupleSigBits, int codeWordBits)
{
    int nbits = 0;
    Bits cword = newBits(tupleSigBits);
    srandom(hash_any(attr_value, strlen(attr_value)));

    while (nbits < codeWordBits) {
        int i = random() % tupleSigBits;
        if (!bitIsSet(cword, i)) {
            setBit(cword, i);
            nbits++;
        }
    }
    return cword;
}

// make a tuple signature

Bits makeTupleSig(Reln r, Tuple t)
{
	assert(r != NULL && t != NULL);
	//TODO
	int nbitsOfTsig = tsigBits(r);// Tuple signature (tuple descriptor) bits
    Bits Tsig = newBits(nbitsOfTsig);
    char **attrsArray = tupleVals(r, t);
    int nattr = nAttrs(r);// Number of attributes

    for (int i = 0; i < nattr; ++i) {
        if (strncmp(attrsArray[i], "?", 1) == 0) {
            continue;
        }
        else {
            Bits cword = generateCodeWord(attrsArray[i], nbitsOfTsig, codeBits(r));
            orBits(Tsig, cword);
        }
    }
	return Tsig;
}

// find "matching" pages using tuple signatures

void findPagesUsingTupSigs(Query q)
{
	assert(q != NULL);
	//TODO
	Reln r = q->rel;
    Bits querySig = makeTupleSig(r, q->qstring);// Making query signature (query descriptor)
    unsetAllBits(q->pages);
    Count numOfTupleSigPages = nTsigPages(r);// Number of pages storing tuple signature (tuple descriptor)
    File tupleSigFile = tsigFile(r);
    Count nTuplePerPage = maxTupsPP(r);// Maximum number of tuples per page
    Count nbitsOfTsig = tsigBits(r);// Tuple signature (tuple descriptor) bits

    for (int pid = 0; pid < numOfTupleSigPages; ++pid) {
        Page p = getPage(tupleSigFile, pid);
        Count numOfTupleSig = pageNitems(p);// The number of tuple signatures (tuple descriptors) in the page
        Bits tupleSig = newBits(nbitsOfTsig);
        for (int tSigID = 0; tSigID < numOfTupleSig; ++tSigID) {
            q->nsigs++;

            getBits(p, tSigID, tupleSig);
            if (isSubset(querySig, tupleSig) == TRUE) {
                Offset pageOffset = q->nsigs / nTuplePerPage;
                setBit(q->pages, pageOffset);
            }
        }
        q->nsigpages++;
    }
    // The printf below is primarily for debugging
    // Remove it before submitting this function
//    printf("Matched Pages:"); showBits(q->pages); putchar('\n');
}
