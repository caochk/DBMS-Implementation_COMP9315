// bsig.c ... functions on Tuple Signatures (bsig's)
// part of signature indexed files
// Written by John Shepherd, March 2019

#include "defs.h"
#include "reln.h"
#include "query.h"
#include "bsig.h"
#include "psig.h"

void findPagesUsingBitSlices(Query q)
{
	assert(q != NULL);
	//TODO
    Reln r = q->rel;
    Bits querySig = makePageSig(r, q->qstring);// Making query signature (query descriptor)
    Count nbitsOfBsig = bsigBits(r);// Bit slice signature (bit slice descriptor) bits

    PageID ppid = -1;
    Count nbitsOfPsig = psigBits(r);// Page signature (page descriptor) bits (i.e. the number of bit slice signatures)
    File bitSliceSigFile = bsigFile(r);

    setAllBits(q->pages);

    for (int i = 0; i < nbitsOfPsig; ++i) {
        Bits bitSliceSig = newBits(nbitsOfBsig);
        if (bitIsSet(querySig, i)) {
            PageID pid = i / maxBsigsPP(r);
            Page p = getPage(bitSliceSigFile, pid);
            if (pid != ppid) {
                q->nsigpages++;
            }
            ppid = pid;

            Count offset = i % maxBsigsPP(r);
            getBits(p, offset, bitSliceSig);

            q->nsigs++;
            Count npageSig = nPsigs(r);
            for (int j = 0; j < npageSig; ++j) {
                if (!bitIsSet(bitSliceSig, j)) {
                    unsetBit(q->pages, j);
                }
            }
        }
    }
}

